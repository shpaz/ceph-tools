Infrastructure playbooks
========================

This directory contains a variety of playbooks that can be used independently of the Ceph roles we have.
They aim to perform infrastructure related tasks that would help use managing a Ceph cluster or performing certain operational tasks.

To use them, **you must move them to ceph-ansible's root directory**, then run using `ansible-playbook <playbook>`.
